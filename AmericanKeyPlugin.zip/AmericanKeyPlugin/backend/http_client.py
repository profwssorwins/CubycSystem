"""Native urllib implementation of http_client to avoid external dependencies like httpx."""

import json
import urllib.request
import urllib.error
import io
import os
import datetime
from typing import Optional, Dict, Any, Generator
from contextlib import contextmanager

from config import HTTP_TIMEOUT_SECONDS
# We'll import logger inside methods to avoid circular imports if needed, 
# but for now let's just use a simple one if logger.py isn't ready.

class Response:
    def __init__(self, fp: Any, status_code: int, headers: Dict[str, str]):
        self.fp = fp
        self.status_code = status_code
        self.headers = headers
        self._content = None

    @property
    def content(self) -> bytes:
        if self._content is None:
            self._content = self.fp.read()
        return self._content

    @property
    def text(self) -> str:
        return self.content.decode('utf-8', errors='replace')

    def json(self) -> Any:
        return json.loads(self.text)

    def raise_for_status(self):
        if self.status_code >= 400:
            raise Exception(f"HTTP Error: {self.status_code}")

    def iter_bytes(self, chunk_size: int = 8192) -> Generator[bytes, None, None]:
        if self._content is not None:
            stream = io.BytesIO(self._content)
            while True:
                chunk = stream.read(chunk_size)
                if not chunk: break
                yield chunk
        else:
            while True:
                chunk = self.fp.read(chunk_size)
                if not chunk: break
                yield chunk

class UrllibClient:
    def __init__(self, timeout: int = 15):
        self.timeout = timeout

    def get(self, url: str, headers: Optional[Dict[str, str]] = None, follow_redirects: bool = True, timeout: Optional[int] = None) -> Response:
        req = urllib.request.Request(url, headers=headers or {})
        try:
            resp = urllib.request.urlopen(req, timeout=timeout or self.timeout)
            return Response(resp, resp.getcode(), dict(resp.info()))
        except urllib.error.HTTPError as e:
            return Response(e, e.code, dict(e.info()))
        except Exception:
            raise

    def post(self, url: str, data: Any = None, headers: Optional[Dict[str, str]] = None, timeout: Optional[int] = None) -> Response:
        json_data = None
        if data is not None:
            json_data = json.dumps(data).encode('utf-8')
            headers = headers or {}
            if 'Content-Type' not in headers:
                headers['Content-Type'] = 'application/json'

        req = urllib.request.Request(url, data=json_data, headers=headers or {}, method='POST')
        try:
            resp = urllib.request.urlopen(req, timeout=timeout or self.timeout)
            return Response(resp, resp.getcode(), dict(resp.info()))
        except urllib.error.HTTPError as e:
            # Urgent: Read body of error if possible
            return Response(e, e.code, dict(e.info()))
        except Exception:
            raise

    @contextmanager
    def stream(self, method: str, url: str, headers: Optional[Dict[str, str]] = None, follow_redirects: bool = True) -> Generator[Response, None, None]:
        req = urllib.request.Request(url, headers=headers or {}, method=method)
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                yield Response(resp, resp.getcode(), dict(resp.info()))
        except urllib.error.HTTPError as e:
            yield Response(e, e.code, dict(e.info()))
        except Exception as e:
            print(f"Stream request failed: {url} - {e}")
            raise

    def close(self):
        pass

_CLIENT = None

def ensure_http_client(context: str = "") -> UrllibClient:
    global _CLIENT
    if _CLIENT is None:
        _CLIENT = UrllibClient(timeout=HTTP_TIMEOUT_SECONDS)
    return _CLIENT

def get_http_client() -> UrllibClient:
    return ensure_http_client()

def close_http_client(context: str = ""):
    pass
