console.log("[AmericanKey] Injecting Simplified Flow + Metadata Fix...");

function debugLog(...args) {
    const msg = args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(" ");
    console.log("[AmericanKey]", msg);
    try {
        Millennium.callServerMethod("americankey", "Logger.log", { message: msg });
    } catch (e) {}
}

let isActivating = false;

async function attemptKeyActivation(key, setStatus, showSuccess, showError) {
    if (isActivating) return;
    isActivating = true;
    setStatus("Verificando...", "#66c0f4");
    try {
        let actResRaw = await Millennium.callServerMethod("americankey", "ActivateProductKey", { key: key });
        let actRes = (typeof actResRaw === 'string') ? JSON.parse(actResRaw) : actResRaw;

        if (!actRes || !actRes.success) {
            showError(actRes?.error || "Código inválido");
            isActivating = false;
            return;
        }

        showSuccess(actRes.games || []);
        isActivating = false;
    } catch (error) { 
        showError(error.message || "Erro de conexão");
        isActivating = false;
    } finally {
        setStatus("", "#fff");
    }
}

function injectCustomUI() {
    if (document.getElementById("ak-footer-bar")) return;

    // Footer Bar
    const footerBar = document.createElement("div");
    footerBar.id = "ak-footer-bar";
    Object.assign(footerBar.style, {
        position: "fixed", bottom: "0px", left: "0", right: "0", width: "100%",
        height: "36px", background: "#171a21", borderTop: "1px solid #2a2e38",
        zIndex: "9998", display: "flex", alignItems: "center", padding: "0",
        fontFamily: "'Motiva Sans', Arial, sans-serif"
    });

    const activateBtn = document.createElement("button");
    activateBtn.innerText = "ATIVAR UM CÓDIGO DE PRODUTO";
    Object.assign(activateBtn.style, {
        background: "transparent", color: "#acb2b8", border: "none", padding: "0 24px",
        height: "100%", cursor: "pointer", fontSize: "11px", fontWeight: "400",
        textTransform: "uppercase", letterSpacing: "1px"
    });

    activateBtn.onmouseover = () => { activateBtn.style.color = "#fff"; activateBtn.style.background = "rgba(255,255,255,0.05)"; };
    activateBtn.onmouseout = () => { activateBtn.style.color = "#acb2b8"; activateBtn.style.background = "transparent"; };
    footerBar.appendChild(activateBtn);
    document.body.appendChild(footerBar);

    // Modal
    const modalOverlay = document.createElement("div");
    Object.assign(modalOverlay.style, {
        position: "fixed", top: "0", left: "0", width: "100%", height: "100%",
        background: "rgba(0, 0, 0, 0.95)", backdropFilter: "blur(12px)",
        zIndex: "1000000", display: "none", justifyContent: "center", alignItems: "center"
    });

    const modalBox = document.createElement("div");
    Object.assign(modalBox.style, {
        background: "#212429", border: "1px solid #3d4450", borderTop: "2px solid #3a69a8",
        borderRadius: "2px", padding: "24px 30px", width: "560px",
        display: "flex", flexDirection: "column", color: "#fff", 
        fontFamily: "'Motiva Sans', Arial, sans-serif", position: "relative"
    });

    const closeX = document.createElement("div"); closeX.innerHTML = "&times;";
    Object.assign(closeX.style, { position: "absolute", top: "10px", right: "15px", fontSize: "20px", color: "#acb2b8", cursor: "pointer" });
    closeX.onclick = () => { if (!isActivating) modalOverlay.style.display = "none"; };

    const inputView = document.createElement("div"); inputView.style.display = "flex"; inputView.style.flexDirection = "column"; inputView.style.gap = "12px";
    const successView = document.createElement("div"); successView.style.display = "none"; successView.style.flexDirection = "column"; successView.style.gap = "18px";
    const errorView = document.createElement("div"); errorView.style.display = "none"; errorView.style.flexDirection = "column"; errorView.style.gap = "18px";

    // --- INPUT VIEW ---
    const title = document.createElement("h2"); title.innerText = "Informe o código de produto";
    Object.assign(title.style, { margin: "0", fontSize: "22px", fontWeight: "400" });
    const desc = document.createElement("p"); desc.innerText = "Ao informar um código, você estará ativando o produto no Steam e adicionando-o à sua biblioteca. Você pode informar um código distribuído com um CD/DVD de varejo ou de outro produto Steam.";
    Object.assign(desc.style, { margin: "0", color: "#acb2b8", fontSize: "13px", lineHeight: "1.4" });
    const exHeader = document.createElement("div"); exHeader.innerText = "EXEMPLOS DE CÓDIGOS";
    Object.assign(exHeader.style, { fontSize: "10px", color: "#66c0f4", fontWeight: "700", marginTop: "4px" });
    const exList = document.createElement("div");
    exList.innerHTML = `<div style="color: #6d7680; font-family: monospace; font-size: 11px; line-height: 1.3;">AAAAA-BBBBB-CCCCC&nbsp;&nbsp;AAAAA-BBBBB-CCCCC-DDDDD-EEEEE<br>AAAAA-BBBBB-CCCCC-DDDDD-EEEEE<br>237ABCDGHJLPRST 23</div>`;
    const input = document.createElement("input"); input.type = "text"; 
    Object.assign(input.style, { background: "rgba(0,0,0,0.5)", border: "1px solid #111", color: "#fff", padding: "10px", borderRadius: "1px", outline: "none", fontSize: "15px" });
    const statusText = document.createElement("div"); Object.assign(statusText.style, { fontSize: "13px", minHeight: "18px", color: "#66c0f4" });
    const btnRow = document.createElement("div"); btnRow.style.display = "flex"; btnRow.style.gap = "8px"; btnRow.style.justifyContent = "flex-end";
    const submitBtn = document.createElement("button"); submitBtn.innerText = "Confirmar";
    Object.assign(submitBtn.style, { background: "#3d4450", color: "#acb2b8", border: "none", padding: "8px 30px", cursor: "pointer", borderRadius: "2px", fontSize: "14px" });
    const cancelBtn = document.createElement("button"); cancelBtn.innerText = "Cancelar";
    Object.assign(cancelBtn.style, { background: "#3d4450", color: "#fff", border: "none", padding: "8px 30px", cursor: "pointer", borderRadius: "2px", fontSize: "14px" });
    btnRow.append(submitBtn, cancelBtn);
    inputView.append(title, desc, exHeader, exList, input, statusText, btnRow);

    // --- SUCCESS VIEW ---
    const sTitle = document.createElement("h2");
    Object.assign(sTitle.style, { margin: "0", fontSize: "22px", fontWeight: "400" });
    const sDesc = document.createElement("p");
    sDesc.innerText = "O seu código de produto foi ativado com sucesso, e o conteúdo dele está associado permanentemente à sua conta Steam. Você deve iniciar a sessão com esta conta para ter acesso aos itens que acabou de ativar no Steam.";
    Object.assign(sDesc.style, { margin: "0", color: "#acb2b8", fontSize: "14px", lineHeight: "1.4" });
    const okBtn = document.createElement("button"); okBtn.innerText = "OK";
    Object.assign(okBtn.style, { 
        background: "linear-gradient(to bottom, #4186a5 5%, #264a5c 95%)", color: "#fff", 
        border: "none", padding: "12px", width: "100%", cursor: "pointer", borderRadius: "2px", fontSize: "14px", fontWeight: "600" 
    });
    successView.append(sTitle, sDesc, okBtn);

    // --- ERROR VIEW ---
    const eTitle = document.createElement("h2"); eTitle.innerText = "Código de produto inválido";
    Object.assign(eTitle.style, { margin: "0", fontSize: "22px", fontWeight: "400" });
    const eDesc = document.createElement("p");
    eDesc.innerText = "O código de produto informado não é válido. Verifique se ele está correto. Pode haver confusão entre as letras I e L e o número 1, entre as letras V e Y e entre o número 0 e a letra O.";
    Object.assign(eDesc.style, { margin: "0", color: "#acb2b8", fontSize: "14px", lineHeight: "1.4" });
    const retryBtn = document.createElement("button"); retryBtn.innerText = "Tentar novamente";
    Object.assign(retryBtn.style, { 
        background: "linear-gradient(to right, #4079ff 0%, #173db4 100%)", color: "#fff", 
        border: "none", padding: "12px", width: "100%", cursor: "pointer", borderRadius: "2px", fontSize: "14px", fontWeight: "600" 
    });
    errorView.append(eTitle, eDesc, retryBtn);

    modalBox.append(inputView, successView, errorView);
    modalOverlay.appendChild(modalBox);
    document.body.appendChild(modalOverlay);

    // Logic
    function switchView(name) {
        inputView.style.display = name === "input" ? "flex" : "none";
        successView.style.display = name === "success" ? "flex" : "none";
        errorView.style.display = name === "error" ? "flex" : "none";
    }

    function showSuccess(games) {
        switchView("success");
        const gameNames = games.length > 0 
            ? games.map(g => (g.name && g.name !== 'Unknown' && !g.name.includes('AppID') && g.name !== 'Jogo') ? g.name : `AppID ${g.appid}`).join(", ") 
            : "Produto Ativado";
        sTitle.innerHTML = `Ativação bem-sucedida: <span style="color: #66c0f4;">${gameNames}</span>`;
    }

    function showError(msg) {
        switchView("error");
        if (msg.toLowerCase().includes("utilizada") || msg.toLowerCase().includes("used")) {
            eTitle.innerText = "Código já utilizado";
            eDesc.innerText = "Este código de produto já foi resgatado por outra conta ou já está presente na sua biblioteca.";
        } else {
            eTitle.innerText = "Código de produto inválido";
            eDesc.innerText = "O código de produto informado não é válido. Verifique se ele está correto. Pode haver confusão entre as letras I e L e o número 1, entre as letras V e Y e entre o número 0 e a letra O.";
        }
    }

    input.oninput = () => {
        if (input.value.trim().length > 0) {
            submitBtn.style.background = "linear-gradient(to right, #4079ff 0%, #173db4 100%)";
            submitBtn.style.color = "#fff";
        } else { submitBtn.style.background = "#3d4450"; submitBtn.style.color = "#acb2b8"; }
    };

    submitBtn.onclick = () => { 
        if (!input.value.trim() || isActivating) return; 
        attemptKeyActivation(input.value.trim(), (t, c) => { statusText.innerText = t; statusText.style.color = c; }, showSuccess, showError); 
    };

    okBtn.onclick = () => modalOverlay.style.display = "none";
    retryBtn.onclick = () => { switchView("input"); input.focus(); };
    cancelBtn.onclick = () => modalOverlay.style.display = "none";
    activateBtn.onclick = () => {
        modalOverlay.style.display = "flex"; switchView("input");
        input.value = ""; input.oninput(); statusText.innerText = ""; setTimeout(() => input.focus(), 50);
    };
    input.onkeyup = (e) => { if (e.key === "Enter") submitBtn.click(); };
}

setInterval(() => { if (document.body && !document.getElementById("ak-footer-bar")) injectCustomUI(); }, 500);
