"""Shared logger instance for the AmericanKey plugin backend."""

import os
import datetime
from paths import get_plugin_dir

# Try to import PluginUtils, but don't fail if it's missing
try:
    import PluginUtils  # type: ignore
    HAS_PLUGIN_UTILS = True
except ImportError:
    HAS_PLUGIN_UTILS = False

class MultiLogger:
    def __init__(self):
        self.millennium_logger = None
        if HAS_PLUGIN_UTILS:
            try:
                self.millennium_logger = PluginUtils.Logger()
            except:
                pass
        
        # Ensure debug_ak.txt is in the plugin root
        self.log_file = os.path.join(get_plugin_dir(), "debug_ak.txt")

    def _write_to_file(self, level: str, message: str):
        try:
            timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write(f"[{timestamp}] [{level}] {message}\n")
        except:
            pass

    def log(self, message: str):
        print(f"[AK-LOG] {message}")
        self._write_to_file("INFO", message)
        if self.millennium_logger:
            try: self.millennium_logger.log(message)
            except: pass

    def warn(self, message: str):
        print(f"[AK-WARN] {message}")
        self._write_to_file("WARN", message)
        if self.millennium_logger:
            try: self.millennium_logger.warn(message)
            except: pass

    def error(self, message: str):
        print(f"[AK-ERROR] {message}")
        self._write_to_file("ERROR", message)
        if self.millennium_logger:
            try: self.millennium_logger.error(message)
            except: pass

_LOGGER_INSTANCE = MultiLogger()

# Convenience alias
logger = _LOGGER_INSTANCE
